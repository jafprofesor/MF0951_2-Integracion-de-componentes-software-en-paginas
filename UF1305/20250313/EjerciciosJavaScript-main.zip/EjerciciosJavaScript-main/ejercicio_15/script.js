// EJERCICIO 15: Detectar tecla presionada
// Enunciado: Mostrar la tecla presionada por el usuario en un párrafo.

// PASOS:
// 1. Agregar un event listener al documento para detectar 'keydown'.
// 2. En el evento, capturar la tecla presionada con event.key.
// 3. Mostrar el valor en el párrafo.

