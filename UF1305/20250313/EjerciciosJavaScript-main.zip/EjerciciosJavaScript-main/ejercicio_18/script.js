// EJERCICIO 18: Evento submit en formulario
// Enunciado: Cuando el usuario envíe el formulario, se debe mostrar un saludo con su nombre.

// PASOS:
// 1. Seleccionar el formulario y el párrafo con document.getElementById.
// 2. Agregar un event listener al formulario para detectar 'submit'.
// 3. En el evento, evitar la recarga de la página con preventDefault().
// 4. Obtener el valor del input y mostrarlo en el párrafo.

