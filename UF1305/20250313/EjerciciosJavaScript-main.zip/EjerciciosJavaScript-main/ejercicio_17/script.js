// EJERCICIO 17: Evento de cambio en select
// Enunciado: Cuando el usuario seleccione una opción del menú desplegable, mostrarla en un párrafo.

// PASOS:
// 1. Seleccionar el <select> y el párrafo con document.getElementById.
// 2. Agregar un event listener al <select> para detectar 'change'.
// 3. En el evento, obtener el valor seleccionado y mostrarlo en el párrafo.

