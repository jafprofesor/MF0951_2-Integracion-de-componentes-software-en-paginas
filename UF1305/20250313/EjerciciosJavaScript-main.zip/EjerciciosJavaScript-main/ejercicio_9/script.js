// EJERCICIO 9: Contador de clics
// Enunciado: Cada vez que el usuario haga clic en el botón, el contador debe aumentar.

// PASOS:
// 1. Seleccionar el botón con document.getElementById.
// 2. Agregar un event listener al botón para detectar 'click'.
// 3. En el evento, incrementar una variable contador y actualizar el texto del botón.

