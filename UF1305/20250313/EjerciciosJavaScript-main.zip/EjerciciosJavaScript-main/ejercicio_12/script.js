// EJERCICIO 12: Evento keydown
// Enunciado: Cuando el usuario escriba en el input, el texto debe reflejarse en un párrafo.

// PASOS:
// 1. Seleccionar el input y el párrafo con document.getElementById.
// 2. Agregar un event listener al input para detectar 'keydown'.
// 3. En el evento, actualizar el texto del párrafo con el valor del input.

