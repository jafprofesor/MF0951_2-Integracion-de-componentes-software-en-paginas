// SOLUCIÓN DEL EJERCICIO 3: Cambiar imagen
document.getElementById("boton").addEventListener("click", function () {
  document.getElementById("imagen").setAttribute("src", "imagen2.png");
});
