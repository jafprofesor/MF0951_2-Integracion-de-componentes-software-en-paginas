// EJERCICIO 3: Cambiar imagen
// Enunciado: Al hacer clic en el botón, la imagen debe cambiar de src.

// PASOS:
// 1. Seleccionar la imagen y el botón con document.getElementById.
// 2. Agregar un event listener al botón para detectar el evento 'click'.
// 3. Dentro del evento, modificar el atributo src de la imagen con setAttribute.

