// EJERCICIO 2: Modificar estilos
// Enunciado: Cuando el usuario haga clic en el botón, el color del párrafo cambiará.

// PASOS:
// 1. Seleccionar el botón y el párrafo con document.getElementById.
// 2. Agregar un event listener al botón para detectar el evento 'click'.
// 3. Modificar la propiedad style.color del párrafo.

