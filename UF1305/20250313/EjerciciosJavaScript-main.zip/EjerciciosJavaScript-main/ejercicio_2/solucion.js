// SOLUCIÓN DEL EJERCICIO 2: Modificar estilos
document.getElementById("boton").addEventListener("click", function() {
    document.getElementById("texto").style.color = "red";
});
