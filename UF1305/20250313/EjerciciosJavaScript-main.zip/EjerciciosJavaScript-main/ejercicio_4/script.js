// EJERCICIO 4: Agregar elementos a una lista
// Enunciado: Cuando el usuario haga clic en el botón, se debe agregar un nuevo <li> a la lista.

// PASOS:
// 1. Seleccionar la lista y el botón con document.getElementById.
// 2. Agregar un event listener al botón para detectar el evento 'click'.
// 3. Crear un nuevo elemento <li> con document.createElement.
// 4. Agregarle texto con textContent y añadirlo a la lista con appendChild.

