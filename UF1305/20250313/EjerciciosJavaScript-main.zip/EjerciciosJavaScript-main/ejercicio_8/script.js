// EJERCICIO 8: Almacenar datos en localStorage
// Enunciado: Guardar el nombre ingresado en un input y mostrarlo al recargar la página.

// PASOS:
// 1. Seleccionar el input, el botón y el párrafo con document.getElementById.
// 2. Agregar un event listener al botón para detectar 'click'.
// 3. En el evento, almacenar el valor del input en localStorage.
// 4. Al cargar la página, recuperar el valor y mostrarlo en el párrafo.

