// EJERCICIO 10: Petición HTTP con Fetch
// Enunciado: Al hacer clic en el botón, obtener datos de una API y mostrarlos en pantalla.

// PASOS:
// 1. Seleccionar el botón y el div donde se mostrarán los datos con document.getElementById.
// 2. Agregar un event listener al botón para detectar 'click'.
// 3. Dentro del evento, usar fetch para obtener datos de la API.
// 4. Convertir la respuesta a JSON y mostrarla en el div.

