// EJERCICIO 20: Evento de arrastrar y soltar
// Enunciado: Permitir que un div sea arrastrado y soltado en otro div.

// PASOS:
// 1. Seleccionar los elementos de arrastre y destino con document.getElementById.
// 2. Agregar un event listener al elemento de arrastre para detectar 'dragstart'.
// 3. Agregar un event listener al destino para detectar 'dragover' y evitar el comportamiento por defecto.
// 4. Agregar un event listener al destino para detectar 'drop' y mover el elemento.

