// SOLUCIÓN DEL EJERCICIO 6: Alternar clases con classList
document.getElementById("boton").addEventListener("click", function() {
    document.getElementById("caja").classList.toggle("activo");
});
