// EJERCICIO 11: Evento mouseover
// Enunciado: Cuando el usuario pase el mouse sobre el div, su color debe cambiar.

// PASOS:
// 1. Seleccionar el div con document.getElementById.
// 2. Agregar un event listener al div para detectar el evento 'mouseover'.
// 3. Dentro del evento, cambiar el color de fondo del div.
// 4. Agregar otro event listener para 'mouseout' que restaure el color original.

