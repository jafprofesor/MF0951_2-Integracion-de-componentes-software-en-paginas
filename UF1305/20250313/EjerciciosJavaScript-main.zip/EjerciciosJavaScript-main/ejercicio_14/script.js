// EJERCICIO 14: Evento focus y blur
// Enunciado: Cuando el usuario haga focus en el input, su borde debe cambiar.
// Al perder el foco (blur), debe volver al estilo original.

// PASOS:
// 1. Seleccionar el input con document.getElementById.
// 2. Agregar un event listener para detectar 'focus' y cambiar el borde.
// 3. Agregar otro event listener para detectar 'blur' y restaurar el borde.

