// SOLUCIÓN DEL EJERCICIO 1: Modificar contenido
document.getElementById("boton").addEventListener("click", function() {
    document.getElementById("texto").textContent = "Texto cambiado";
});
