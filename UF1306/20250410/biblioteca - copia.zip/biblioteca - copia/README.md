# Guía de Instalación - Sistema de Biblioteca

Esta guía te ayudará a instalar y ejecutar el sistema de gestión de biblioteca en tu equipo local.

## Requisitos Previos

Antes de comenzar, asegúrate de tener instalado:

1. **Node.js** (versión 14 o superior) - [Descargar Node.js](https://nodejs.org/)
2. **MongoDB** (versión 4.4 o superior) - [Descargar MongoDB](https://www.mongodb.com/try/download/community)
3. **Git** (opcional, para clonar el repositorio) - [Descargar Git](https://git-scm.com/downloads)

## Pasos de Instalación

### 1. Descomprimir el Archivo

- Descomprime el archivo `biblioteca.zip` en la ubicación que prefieras en tu equipo.

### 2. Configurar MongoDB

- Asegúrate de que MongoDB esté instalado y en ejecución en tu sistema.
- Por defecto, la aplicación se conectará a `mongodb://localhost:27017/biblioteca`.
- Si necesitas usar una configuración diferente, modifica el archivo `.env` en la carpeta `backend`.

### 3. Instalar Dependencias del Backend

1. Abre una terminal o línea de comandos.
2. Navega hasta la carpeta `backend` dentro del proyecto:
   ```
   cd ruta/a/tu/proyecto/backend
   ```
3. Instala las dependencias necesarias:
   ```
   npm install
   ```

### 4. Crear Usuario Administrador

1. Desde la carpeta `backend`, ejecuta el script para crear un usuario administrador:
   ```
   node scripts/createAdmin.js
   ```
2. Esto creará un usuario administrador con las siguientes credenciales:
   - Email: juan@ellisto.com
   - Contraseña: 123456

### 5. Iniciar el Servidor Backend

1. Desde la carpeta `backend`, inicia el servidor:
   ```
   node server.js
   ```
2. Deberías ver un mensaje indicando que el servidor está en ejecución en el puerto 5000 y conectado a MongoDB.

### 6. Acceder a la Aplicación

1. Abre tu navegador web.
2. Navega a la siguiente URL:
   ```
   http://localhost:5000/frontend/index.html
   ```
3. Inicia sesión con las credenciales del administrador creadas anteriormente.

## Estructura del Proyecto

- **frontend/**: Contiene todos los archivos de la interfaz de usuario (HTML, CSS, JavaScript).
- **backend/**: Contiene el código del servidor y la API.
  - **models/**: Definiciones de los modelos de datos (MongoDB/Mongoose).
  - **routes/**: Endpoints de la API REST.
  - **middleware/**: Funciones intermediarias como autenticación.
  - **scripts/**: Scripts útiles como la creación del administrador.

## Solución de Problemas

- **Error de conexión a MongoDB**: Asegúrate de que MongoDB esté en ejecución y accesible en la URL especificada en el archivo `.env`.
- **Error al iniciar el servidor**: Verifica que el puerto 5000 no esté siendo utilizado por otra aplicación.
- **Problemas de acceso a la aplicación**: Asegúrate de que el servidor backend esté en ejecución y que estés accediendo a la URL correcta.

## Notas Adicionales

- Esta aplicación es solo para fines educativos.
- Para un entorno de producción, se recomienda configurar medidas de seguridad adicionales.
- Recuerda cambiar las credenciales del administrador después de la primera instalación.

---
