const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Conectado a MongoDB"))
  .catch((err) => console.error("Error de conexión", err));

const authRoutes = require("./routes/usuarios");
const libroRoutes = require("./routes/libros");
const reservaRoutes = require("./routes/reservas");

app.use("/api/usuarios", authRoutes);
app.use("/api/libros", libroRoutes);
app.use("/api/reservas", reservaRoutes);
app.use(express.static(path.join(__dirname, "../frontend")));

app.get("/*", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`Servidor corriendo en http://localhost:${PORT}`)
);
