const jwt = require("jsonwebtoken");

// Middleware to verify JWT token
const auth = (req, res, next) => {
  // Get token from header
  const token = req.header("Authorization");

  // Check if no token
  if (!token) {
    return res.status(401).json({ msg: "No token, authorization denied" });
  }

  try {
    // Verify token
    // Check if token has Bearer prefix and remove it
    const tokenValue = token.startsWith("Bearer ") ? token.slice(7) : token;
    const decoded = jwt.verify(tokenValue, "secreto");

    // Add user from payload
    req.usuario = decoded;
    next();
  } catch (err) {
    res.status(401).json({ msg: "Token is not valid" });
  }
};

function adminAuth(req, res, next) {
  if (req.usuario.rol !== "administrador") {
    return res.status(403).json({ error: "Acceso denegado" });
  }
  next();
}

module.exports = { auth, adminAuth };
