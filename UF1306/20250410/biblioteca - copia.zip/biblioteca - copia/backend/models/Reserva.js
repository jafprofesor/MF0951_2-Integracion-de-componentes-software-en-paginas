const mongoose = require("mongoose");

const reservaSchema = new mongoose.Schema({
  usuario: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Usuario",
    required: true,
  },
  libro: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Libro",
    required: true,
  },
  fechaInicio: {
    type: Date,
    required: true,
    default: Date.now,
  },
  fechaFin: {
    type: Date,
    required: true,
  },
  estado: {
    type: String,
    enum: ["pendiente", "activa", "completada", "cancelada"],
    default: "pendiente",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Reserva = mongoose.model("Reserva", reservaSchema);

module.exports = Reserva;
