const mongoose = require("mongoose");

const libroSchema = new mongoose.Schema({
  titulo: {
    type: String,
    required: true,
  },
  autor: {
    type: String,
    required: true,
  },
  editorial: {
    type: String,
  },
  anioPublicacion: {
    type: Number,
  },
  genero: {
    type: String,
  },
  disponible: {
    type: Boolean,
    default: true,
  },
  imagen: {
    type: String,
  },
  descripcion: {
    type: String,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

const Libro = mongoose.model("Libro", libroSchema);

module.exports = Libro;
