const mongoose = require("mongoose");
const Usuario = require("../models/Usuario");
require("dotenv").config();

// Conectar a MongoDB
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Conectado a MongoDB"))
  .catch((err) => console.error("Error de conexión", err));

// Crear usuario administrador
async function createAdmin() {
  try {
    // Verificar si el usuario ya existe
    const existingUser = await Usuario.findOne({ email: "juan@ellisto.com" });

    if (existingUser) {
      console.log("El usuario administrador ya existe");
      mongoose.connection.close();
      return;
    }

    // Crear nuevo usuario administrador
    const admin = new Usuario({
      nombre: "juan",
      email: "juan@ellisto.com",
      password: "123456",
      rol: "administrador",
    });

    await admin.save();
    console.log("Usuario administrador creado con éxito");
    mongoose.connection.close();
  } catch (error) {
    console.error("Error al crear usuario administrador:", error);
    mongoose.connection.close();
  }
}

createAdmin();
