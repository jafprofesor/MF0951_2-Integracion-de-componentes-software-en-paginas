const express = require("express");
const jwt = require("jsonwebtoken");
const Usuario = require("../models/Usuario");
const { auth, adminAuth } = require("../middleware/auth");
const router = express.Router();

// Crear usuario administrador
router.post("/crear-admin", auth, adminAuth, async (req, res) => {
  try {
    const { nombre, email, password } = req.body;
    const usuario = new Usuario({
      nombre,
      email,
      password,
      rol: "administrador",
    });
    await usuario.save();
    res.json(usuario);
  } catch (error) {
    res.status(500).json({ error: "Error al crear administrador" });
  }
});

// Obtener todos los usuarios
router.get("/", auth, adminAuth, async (req, res) => {
  const usuarios = await Usuario.find();
  res.json(usuarios);
});

router.post("/registro", async (req, res) => {
  const { nombre, email, password } = req.body;
  try {
    const existente = await Usuario.findOne({ email });
    if (existente) return res.status(400).json({ error: "Usuario ya existe" });
    const nuevoUsuario = new Usuario({ nombre, email, password });
    await nuevoUsuario.save();
    res.json({ mensaje: "Usuario registrado correctamente" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const usuario = await Usuario.findOne({ email });
    if (!usuario)
      return res.status(404).json({ error: "Usuario no encontrado" });
    const valido = await usuario.comparePassword(password);
    if (!valido)
      return res.status(400).json({ error: "Contraseña incorrecta" });
    const token = jwt.sign(
      { id: usuario._id, nombre: usuario.nombre, rol: usuario.rol },
      "secreto"
    );
    res.json({ token, nombre: usuario.nombre, rol: usuario.rol });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
