const express = require("express");
const Libro = require("../models/Libro");
const { auth, adminAuth } = require("../middleware/auth");
const router = express.Router();

router.get("/", async (req, res) => {
  const libros = await Libro.find();
  res.json(libros);
});

router.post("/", auth, adminAuth, async (req, res) => {
  try {
    const { titulo, autor, portada } = req.body;
    const libro = new Libro({ titulo, autor, imagen: portada });
    await libro.save();
    res.json(libro);
  } catch (error) {
    res.status(500).json({ error: "Error al agregar el libro" });
  }
});

router.put("/:id/reservar", auth, async (req, res) => {
  const libro = await Libro.findById(req.params.id);
  if (!libro || !libro.disponible)
    return res.status(400).json({ error: "No disponible" });
  libro.disponible = false;
  await libro.save();
  res.json(libro);
});

router.put("/:id/devolver", auth, async (req, res) => {
  const libro = await Libro.findById(req.params.id);
  if (!libro || libro.disponible)
    return res.status(400).json({ error: "El libro ya está disponible" });
  libro.disponible = true;
  await libro.save();
  res.json(libro);
});

router.delete("/:id", auth, async (req, res) => {
  try {
    const libro = await Libro.findByIdAndDelete(req.params.id);
    if (!libro) return res.status(404).json({ error: "Libro no encontrado" });
    res.json({ mensaje: "Libro eliminado correctamente" });
  } catch (error) {
    res.status(500).json({ error: "Error al eliminar el libro" });
  }
});

module.exports = router;
