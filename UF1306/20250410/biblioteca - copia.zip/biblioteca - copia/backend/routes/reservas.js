const express = require("express");
const Reserva = require("../models/Reserva");
const { auth } = require("../middleware/auth");
const router = express.Router();

router.post("/", auth, async (req, res) => {
  const { libroId, fechaDevolucion } = req.body;
  try {
    const reserva = new Reserva({
      libro: libroId,
      usuario: req.usuario.id,
      fechaDevolucion,
    });
    await reserva.save();
    res.json(reserva);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/mias", auth, async (req, res) => {
  const reservas = await Reserva.find({ usuario: req.usuario.id }).populate(
    "libro"
  );
  res.json(reservas);
});

module.exports = router;
