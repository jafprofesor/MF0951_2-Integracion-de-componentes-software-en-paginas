const API = "http://localhost:5000/api";
const token = localStorage.getItem("token");
const userRole = localStorage.getItem("userRole");

// Inicialización
document.addEventListener("DOMContentLoaded", () => {
  // Configurar eventos de navegación
  document
    .getElementById("nav-inicio")
    .addEventListener("click", mostrarInicio);
  document
    .getElementById("nav-login")
    .addEventListener("click", mostrarLoginModal);
  document
    .getElementById("nav-registro")
    .addEventListener("click", mostrarRegistroModal);
  document.getElementById("nav-logout").addEventListener("click", logout);

  // Verificar si hay sesión activa
  if (token) {
    mostrarLibros();
    actualizarNavegacion(true);
  } else {
    mostrarInicio();
    actualizarNavegacion(false);
  }

  // Cargar libros al inicio independientemente del estado de login
  cargarLibros();
});

// Función para actualizar la navegación según el estado de autenticación
function actualizarNavegacion(autenticado) {
  // Elementos de navegación
  if (autenticado) {
    document.getElementById("nav-login-item").classList.add("d-none");
    document.getElementById("nav-registro-item").classList.add("d-none");
    document.getElementById("nav-logout-item").classList.remove("d-none");
  } else {
    document.getElementById("nav-login-item").classList.remove("d-none");
    document.getElementById("nav-registro-item").classList.remove("d-none");
    document.getElementById("nav-logout-item").classList.add("d-none");
  }

  // Controlar visibilidad de elementos de administrador
  const adminControls = document.querySelectorAll(".admin-only");
  if (autenticado && localStorage.getItem("userRole") === "administrador") {
    adminControls.forEach((el) => el.classList.remove("d-none"));
  } else {
    adminControls.forEach((el) => el.classList.add("d-none"));
  }
}

function login(email, password) {
  fetch(API + "/usuarios/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.token) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("usuario", data.nombre);
        localStorage.setItem("userRole", data.rol);
        mostrarLibros();
        actualizarNavegacion(true);
        Swal.fire({
          icon: "success",
          title: "¡Bienvenido!",
          text: `Has iniciado sesión como ${data.nombre}`,
          timer: 2000,
          showConfirmButton: false,
        });
      } else Swal.fire("Error", data.error, "error");
    })
    .catch((error) => {
      Swal.fire("Error", "Error de conexión al servidor", "error");
    });
}

function registro(nombre, email, password) {
  // Validar campos
  if (!nombre || !email || !password) {
    Swal.fire("Error", "Todos los campos son obligatorios", "error");
    return;
  }

  fetch(API + "/usuarios/registro", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nombre, email, password }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.mensaje) {
        Swal.fire({
          icon: "success",
          title: "Registro exitoso",
          text: data.mensaje,
          confirmButtonText: "Iniciar sesión ahora",
        }).then((result) => {
          if (result.isConfirmed) {
            mostrarLoginModal();
          }
        });
      } else Swal.fire("Error", data.error, "error");
    })
    .catch((error) => {
      Swal.fire("Error", "Error de conexión al servidor", "error");
    });
}

// Función para mostrar la página de inicio (libros sin opciones de reserva)
function mostrarInicio() {
  document.getElementById("auth-section").classList.add("d-none");
  document.getElementById("libros-section").classList.remove("d-none");

  // Mostrar contenedor de libros
  const librosContainer = document.getElementById("libros-container");
  librosContainer.classList.remove("d-none");

  // Cargar libros
  cargarLibros();
}

// Función para cargar libros (utilizada tanto en inicio como cuando el usuario está logueado)
function cargarLibros() {
  fetch(API + "/libros")
    .then((res) => res.json())
    .then((data) => {
      const cont = document.getElementById("libros-container");
      cont.innerHTML = "";
      data.forEach((libro) => {
        const col = document.createElement("div");
        col.className = "col-md-4";

        // Verificar si el usuario está autenticado para mostrar botones de reserva
        let botonesHTML = "";
        if (localStorage.getItem("token")) {
          const esAdmin = localStorage.getItem("userRole") === "administrador";

          botonesHTML = '<div class="d-flex gap-2">';

          // Botón de reservar (solo para usuarios autenticados)
          if (libro.disponible) {
            botonesHTML += `<button onclick="reservar('${libro._id}')" class="btn btn-warning">Reservar</button>`;
          }

          // Botones de administrador
          if (esAdmin) {
            botonesHTML += `<button onclick="eliminarLibro('${libro._id}')" class="btn btn-danger">Eliminar</button>`;

            if (!libro.disponible) {
              botonesHTML += `<button onclick="devolver('${libro._id}')" class="btn btn-warning">Devolver</button>`;
            }
          }

          botonesHTML += "</div>";
        } else {
          // Si no está autenticado, mostrar botón para iniciar sesión
          botonesHTML = `<button onclick="mostrarLoginModal()" class="btn btn-primary">Iniciar sesión para reservar</button>`;
        }

        col.innerHTML = `
          <div class="card mb-3">
            <img src="${libro.imagen || libro.portada}" class="card-img-top">
            <div class="card-body">
              <h5 class="card-title">${libro.titulo}</h5>
              <p class="card-text">Autor: ${libro.autor}</p>
              <p class="card-text"><small>${
                libro.disponible ? "Disponible" : "Reservado"
              }</small></p>
              ${botonesHTML}
            </div>
          </div>`;
        cont.appendChild(col);
      });
    })
    .catch((error) => {
      console.error("Error al cargar libros:", error);
      Swal.fire("Error", "No se pudieron cargar los libros", "error");
    });
}

// Función para mostrar modal de login con SweetAlert2
function mostrarLoginModal() {
  Swal.fire({
    title: "Iniciar Sesión",
    html: `
      <input type="email" id="swal-email" class="swal2-input" placeholder="Email">
      <input type="password" id="swal-password" class="swal2-input" placeholder="Contraseña">
    `,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Iniciar Sesión",
    cancelButtonText: "Cancelar",
    preConfirm: () => {
      const email = document.getElementById("swal-email").value;
      const password = document.getElementById("swal-password").value;

      if (!email || !password) {
        Swal.showValidationMessage("Por favor ingresa email y contraseña");
        return false;
      }

      return { email, password };
    },
  }).then((result) => {
    if (result.isConfirmed) {
      login(result.value.email, result.value.password);
    }
  });
}

// Función para mostrar modal de registro con SweetAlert2
function mostrarRegistroModal() {
  Swal.fire({
    title: "Registro de Usuario",
    html: `
      <input type="text" id="swal-nombre" class="swal2-input" placeholder="Nombre">
      <input type="email" id="swal-email" class="swal2-input" placeholder="Email">
      <input type="password" id="swal-password" class="swal2-input" placeholder="Contraseña">
    `,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Registrarse",
    cancelButtonText: "Cancelar",
    preConfirm: () => {
      const nombre = document.getElementById("swal-nombre").value;
      const email = document.getElementById("swal-email").value;
      const password = document.getElementById("swal-password").value;

      if (!nombre || !email || !password) {
        Swal.showValidationMessage("Todos los campos son obligatorios");
        return false;
      }

      return { nombre, email, password };
    },
  }).then((result) => {
    if (result.isConfirmed) {
      registro(result.value.nombre, result.value.email, result.value.password);
    }
  });
}

// Estas funciones se mantienen para compatibilidad, pero ahora redirigen a los modales
function mostrarLogin() {
  mostrarLoginModal();
}

function mostrarRegistro() {
  mostrarRegistroModal();
}

function mostrarLibros() {
  document.getElementById("auth-section").classList.add("d-none");
  document.getElementById("libros-section").classList.remove("d-none");
  document.getElementById("usuario-nombre").innerText =
    localStorage.getItem("usuario");

  // Mostrar u ocultar controles de administrador
  const esAdmin = localStorage.getItem("userRole") === "administrador";
  const adminControls = document.querySelectorAll(".admin-only");
  adminControls.forEach((el) => {
    if (esAdmin) {
      el.classList.remove("d-none");
    } else {
      el.classList.add("d-none");
    }
  });

  // Usar la función común para cargar libros
  cargarLibros();
}

function agregarLibro() {
  // Verificar si el usuario es administrador
  if (localStorage.getItem("userRole") !== "administrador") {
    Swal.fire("Error", "No tienes permisos para realizar esta acción", "error");
    return;
  }

  const titulo = document.getElementById("titulo").value;
  const autor = document.getElementById("autor").value;
  const portada = document.getElementById("portada").value;
  fetch(API + "/libros", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ titulo, autor, portada }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        Swal.fire("Error", data.error, "error");
      } else {
        Swal.fire("Éxito", "Libro agregado correctamente", "success");
        mostrarLibros();
      }
    })
    .catch(() => {
      Swal.fire("Error", "Error de conexión al servidor", "error");
    });
}

function reservar(id) {
  // Verificar si el usuario está autenticado
  if (!localStorage.getItem("token")) {
    Swal.fire("Error", "Debes iniciar sesión para reservar libros", "error");
    mostrarLogin();
    return;
  }

  fetch(API + "/libros/" + id + "/reservar", {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
      "Content-Type": "application/json",
    },
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        Swal.fire("Error", data.error, "error");
      } else {
        Swal.fire("Éxito", "Libro reservado", "success");
        mostrarLibros();
      }
    })
    .catch(() => {
      Swal.fire("Error", "Error de conexión al servidor", "error");
    });
}

function devolver(id) {
  // Verificar si el usuario es administrador
  if (localStorage.getItem("userRole") !== "administrador") {
    Swal.fire("Error", "No tienes permisos para realizar esta acción", "error");
    return;
  }

  fetch(API + "/libros/" + id + "/devolver", {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
      "Content-Type": "application/json",
    },
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        Swal.fire("Error", data.error, "error");
      } else {
        Swal.fire("Éxito", "Libro devuelto", "success");
        mostrarLibros();
      }
    })
    .catch(() => {
      Swal.fire("Error", "Error de conexión al servidor", "error");
    });
}

function eliminarLibro(id) {
  // Verificar si el usuario es administrador
  if (localStorage.getItem("userRole") !== "administrador") {
    Swal.fire("Error", "No tienes permisos para realizar esta acción", "error");
    return;
  }

  Swal.fire({
    title: "¿Estás seguro?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar",
  }).then((result) => {
    if (result.isConfirmed) {
      fetch(API + "/libros/" + id, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          "Content-Type": "application/json",
        },
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.error) {
            Swal.fire("Error", data.error, "error");
          } else {
            Swal.fire("Eliminado", "El libro ha sido eliminado", "success");
            mostrarLibros();
          }
        })
        .catch(() => {
          Swal.fire("Error", "Error de conexión al servidor", "error");
        });
    }
  });
}

function logout() {
  localStorage.clear();
  actualizarNavegacion(false);
  // Limpiar el nombre de usuario mostrado
  document.getElementById("usuario-nombre").innerText = "";
  mostrarInicio();
}
